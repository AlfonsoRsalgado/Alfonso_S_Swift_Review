var carcollection = ["blueRaceCar", "redCar", "greenCar", "bigTruck", "airplane"]

carcollection.sort()

print("my collection of 5 cars has \(carcollection).")
